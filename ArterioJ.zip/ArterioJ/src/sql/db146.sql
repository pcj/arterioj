drop database db146 if exists;
create database db146;

GRANT ALL PRIVILEGES ON db146.* TO 'arterioj'@'localhost' IDENTIFIED BY 'arterioj' WITH GRANT OPTION;

